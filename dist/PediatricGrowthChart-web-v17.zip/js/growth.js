// Growth references, LMS maths and exact age. Mirrors core/ (Kotlin) of the Android app.
export const REF_IDS = ["who2006_0_2", "cdc2000_child", "cdc2000_infant", "who2006", "who2007",
  "cdc2000_hc", "cdc2000_wfl", "cdc2000_bmi", "who2006_hc", "who2006_bmi", "who2006_wfl", "who2006_wfh", "who2007_bmi",
  "ds_infant", "ds_child", "turner"];
/** Measures: key -> short label. "wfl" = weight-for-length/height (x axis is length, not age). */
export const MEASURES = { height: "Height", weight: "Weight", bmi: "BMI", hc: "Head circ.", wfl: "Weight-for-length" };
export const CONDITIONS = { down: "Down syndrome (trisomy 21)", turner: "Turner syndrome" };
export const FAMILIES = {
  CDC: "CDC 2000 original charts (Set 2): birth–36 months, then 2–20 years from age 2",
  AUTO: "WHO birth–24 months, then CDC 2–20 years original chart (CDC/AAP recommendation)",
  WHO: "WHO (2006 standards 0–5 y, then 2007 reference 5–19 y)",
};
export const DAYS_PER_MONTH = 365.25 / 12;

const refs = {};
export async function loadReferences() {
  await Promise.all(REF_IDS.map(async (id) => {
    const r = await (await fetch(`data/${id}.json`)).json();
    for (const k of Object.keys(r.measures)) {
      const m = r.measures[k];
      m.key = k;
      m.whoTails = r.family === "WHO" && (k === "weight" || k === "bmi" || k === "wfl"); // WHO restricted tails for weight-based indicators
      m.xKind = m.xKind || "age";
    }
    refs[id] = r;
  }));
}
export const getRef = (id) => refs[id];
export const allRefs = () => REF_IDS.map((id) => refs[id]);

/**
 * Reference used for a measure at this age (null when none applies). height/weight follow defaultRefFor;
 * head circumference, BMI and weight-for-length follow the same CDC / CDC-AAP (WHO < 24 mo) / WHO choice.
 */
export function refForKey(family, key, age) {
  if (key === "height" || key === "weight") return defaultRefFor(family, age);
  if (key === "hc") {
    if (family === "WHO") return age <= 60 ? "who2006_hc" : null;
    if (family === "AUTO" && age < 24) return "who2006_hc";
    return age <= 36 ? "cdc2000_hc" : null;
  }
  if (key === "bmi") {
    if (family === "WHO") return age < 60 ? "who2006_bmi" : age <= 228 ? "who2007_bmi" : null;
    if (age < 24) return family === "AUTO" ? "who2006_bmi" : null;
    return age <= 240 ? "cdc2000_bmi" : null;
  }
  if (key === "wfl") {
    if (family === "CDC") return age <= 36 ? "cdc2000_wfl" : null;
    if (age < 24) return "who2006_wfl";
    return family === "WHO" && age <= 60 ? "who2006_wfh" : null;
  }
  return null;
}
/** Condition-specific reference (Down syndrome, Turner syndrome) for a measure at this age, if one exists. */
export function condRefFor(cond, key, age) {
  let id = null;
  if (cond === "down") id = age < 36 ? "ds_infant" : "ds_child";
  if (cond === "turner") id = "turner";
  const r = id && refs[id];
  return r && r.measures[key] && covers(r.measures[key], age) ? id : null;
}

/** Value of a measure in a measurement record ("wfl" is the weight; its x is the length). */
export function mValue(x, key) {
  if (key === "bmi") return x.height && x.weight ? x.weight / (x.height / 100) ** 2 : null;
  if (key === "wfl") return x.height && x.weight ? x.weight : null;
  return x[key] ?? null;
}
/** Percentile assessment of one measure of one visit (x = plotting age, or length for weight-for-length). */
export function assessKey(refId, key, sex, ageMonths, rec) {
  const r = refs[refId]; const m = r?.measures[key]; if (!m) return null;
  const v = mValue(rec, key); if (v == null) return null;
  if (m.xKind === "length") {
    if (ageMonths < (m.ageFrom ?? 0) || ageMonths > (m.ageTo ?? 1e9)) return null;
    return assess(m, sex, rec.height, v);
  }
  return assess(m, sex, ageMonths, v);
}

// ---- corrected age for prematurity
let useCorrection = true;
export function setCorrection(on) { useCorrection = !!on; }
export function correctionOn() { return useCorrection; }
/** Days to subtract for prematurity (40 weeks − gestational age) while chronological age < 24 months; 0 otherwise. */
export function correctionDays(p, dateIso) {
  if (!useCorrection || !p.gaWeeks || p.gaWeeks >= 37) return 0;
  const ga = p.gaWeeks * 7 + (p.gaDays || 0);
  const chrono = epochDay(dateIso) - epochDay(p.dob);
  return chrono < 731 ? Math.max(0, 280 - ga) : 0;
}
/** Age used for plotting and percentiles (corrected for prematurity when that applies). */
export function plotAge(p, dateIso) {
  const a = exactAge(p.dob, dateIso), c = correctionDays(p, dateIso);
  if (!c) return { ...a, corrected: false, chrono: a };
  const shifted = new Date((epochDay(p.dob) + c) * 86400000).toISOString().slice(0, 10);
  const ca = exactAge(shifted, dateIso);
  return { ...ca, corrected: true, chrono: a, corrDays: c };
}
/** "3 m 2 d (corrected 1 m 5 d)" */
export function ageLabel(p, dateIso) {
  const a = plotAge(p, dateIso);
  return a.corrected ? `${a.chrono.text} (corrected ${a.days < 0 ? "before term" : a.text})` : a.text;
}

/** Chart used for a child of this age. AUTO switches from WHO to CDC at exactly 24 months. */
export function defaultRefFor(family, ageMonths) {
  if (family === "AUTO") return ageMonths < 24 ? "who2006_0_2" : "cdc2000_child";
  if (family === "WHO") return ageMonths < 60 ? "who2006" : "who2007";
  return ageMonths < 24 ? "cdc2000_infant" : "cdc2000_child";
}

export function covers(m, age) { return age >= m.ageMin - 1e-9 && age <= m.ageMax + 1e-9; }

export function lms(m, sex, age) {
  if (!covers(m, age)) return null;
  const t = m[sex === "F" ? "female" : "male"];
  if (!t || !t.length) return null;
  if (age < t[0][0] - 1e-9 || age > t[t.length - 1][0] + 1e-9) return null;
  let lo = 0, hi = t.length - 1;
  if (age <= t[0][0]) return t[0].slice(1);
  if (age >= t[hi][0]) return t[hi].slice(1);
  while (hi - lo > 1) { const mid = (lo + hi) >> 1; if (t[mid][0] <= age) lo = mid; else hi = mid; }
  const f = (age - t[lo][0]) / (t[hi][0] - t[lo][0]);
  return t[lo].slice(1).map((v, i) => v + (t[hi][i + 1] - v) * f); // [L, M, S] (+ sigma for CDC BMI)
}
export function valueAt([L, M, S], z) { return Math.abs(L) < 1e-9 ? M * Math.exp(S * z) : M * Math.pow(1 + L * S * z, 1 / L); }
export function zOf([L, M, S], x) { return Math.abs(L) < 1e-9 ? Math.log(x / M) / S : (Math.pow(x / M, L) - 1) / (L * S); }

export function centileValue(m, sex, age, c) { const p = lms(m, sex, age); return p ? valueAt(p, invNorm(c / 100)) : null; }
export function zValue(m, sex, age, z) { const p = lms(m, sex, age); return p ? valueAt(p, z) : null; }

export function assess(m, sex, age, x) {
  if (!(x > 0)) return null;
  const p = lms(m, sex, age); if (!p) return null;
  let z = zOf(p, x);
  if (m.whoTails && Math.abs(z) > 3) {
    if (z > 3) { const s3 = valueAt(p, 3), s2 = valueAt(p, 2); z = 3 + (x - s3) / (s3 - s2); }
    else { const s3 = valueAt(p, -3), s2 = valueAt(p, -2); z = -3 + (x - s3) / (s2 - s3); }
  }
  // CDC 2022 extended BMI-for-age: above the 95th percentile, percentile = 90 + 10 * Phi((BMI - P95) / sigma)
  if (m.extBmi && p.length > 3 && z >= invNorm(0.95)) {
    const p95 = valueAt(p, invNorm(0.95)), pc = 90 + 10 * cdf((x - p95) / p[3]);
    return { z, p: pc, ext: true, pctOfP95: x / p95 * 100 };
  }
  return { z, p: cdf(z) * 100 };
}

/** Percentile only, e.g. "45th percentile"; extremes with one decimal ("0.4th", "99.6th"). */
export function fmtAssess(a) {
  if (!a) return "–";
  const p = a.p;
  if (p < 0.1) return "<0.1st percentile";
  if (p > 99.9) return ">99.9th percentile";
  const v = p < 1 || p > 99 ? Math.round(p * 10) / 10 : Math.min(99, Math.max(1, Math.round(p)));
  return `${v}${ordinal(v)} percentile`;
}
function ordinal(v) {
  if (!Number.isInteger(v)) return "th";
  const t = v % 100; if (t >= 11 && t <= 13) return "th";
  return ["th", "st", "nd", "rd"][v % 10] || "th";
}

// ---- normal distribution
export function cdf(z) { return 0.5 * erfc(-z / Math.SQRT2); }
const COF = [-1.3026537197817094, 6.4196979235649026e-1, 1.9476473204185836e-2, -9.561514786808631e-3, -9.46595344482036e-4, 3.66839497852761e-4, 4.2523324806907e-5, -2.0278578112534e-5, -1.624290004647e-6, 1.303655835580e-6, 1.5626441722e-8, -8.5238095915e-8, 6.529054439e-9, 5.059343495e-9, -9.91364156e-10, -2.27365122e-10, 9.6467911e-11, 2.394038e-12, -6.886027e-12, 8.94487e-13, 3.13092e-13, -1.12708e-13, 3.81e-16, 7.106e-15, -1.523e-15, -9.4e-17, 1.21e-16, -2.8e-17];
function erfc(x) {
  const z = Math.abs(x), t = 2 / (2 + z), ty = 4 * t - 2;
  let d = 0, dd = 0;
  for (let j = COF.length - 1; j > 0; j--) { const tmp = d; d = ty * d - dd + COF[j]; dd = tmp; }
  const r = t * Math.exp(-z * z + 0.5 * (COF[0] + ty * d) - dd);
  return x >= 0 ? r : 2 - r;
}
export function invNorm(p) {
  const a = [-39.69683028665376, 220.9460984245205, -275.9285104469687, 138.357751867269, -30.66479806614716, 2.506628277459239];
  const b = [-54.47609879822406, 161.5858368580409, -155.6989798598866, 66.80131188771972, -13.28068155288572];
  const c = [-0.007784894002430293, -0.3223964580411365, -2.400758277161838, -2.549732539343734, 4.374664141464968, 2.938163982698783];
  const d = [0.007784695709041462, 0.3224671290700398, 2.445134137142996, 3.754408661907416];
  let x, q, r;
  if (p < 0.02425) { q = Math.sqrt(-2 * Math.log(p)); x = (((((c[0] * q + c[1]) * q + c[2]) * q + c[3]) * q + c[4]) * q + c[5]) / ((((d[0] * q + d[1]) * q + d[2]) * q + d[3]) * q + 1); }
  else if (p <= 1 - 0.02425) { q = p - 0.5; r = q * q; x = (((((a[0] * r + a[1]) * r + a[2]) * r + a[3]) * r + a[4]) * r + a[5]) * q / (((((b[0] * r + b[1]) * r + b[2]) * r + b[3]) * r + b[4]) * r + 1); }
  else { q = Math.sqrt(-2 * Math.log(1 - p)); x = -(((((c[0] * q + c[1]) * q + c[2]) * q + c[3]) * q + c[4]) * q + c[5]) / ((((d[0] * q + d[1]) * q + d[2]) * q + d[3]) * q + 1); }
  const e = cdf(x) - p, u = e * Math.sqrt(2 * Math.PI) * Math.exp(x * x / 2);
  return x - u / (1 + x * u / 2);
}

// ---- dates (stored as "YYYY-MM-DD"; all arithmetic in UTC days)
export function epochDay(iso) { const [y, m, d] = iso.split("-").map(Number); return Math.round(Date.UTC(y, m - 1, d) / 86400000); }
export function todayIso() { const n = new Date(); return `${n.getFullYear()}-${String(n.getMonth() + 1).padStart(2, "0")}-${String(n.getDate()).padStart(2, "0")}`; }
export function fmtDate(iso) { if (!iso) return ""; const [y, m, d] = iso.split("-"); return `${d}/${m}/${y}`; }
function daysInMonth(y, m) { return new Date(Date.UTC(y, m, 0)).getUTCDate(); } // m = 1..12

/** Exact chronological age. Same rules as java.time.Period.between (used by the Android app). */
export function exactAge(dobIso, dateIso) {
  const days = epochDay(dateIso) - epochDay(dobIso);
  const [y1, m1, d1] = dobIso.split("-").map(Number);
  const [y2, m2, d2] = dateIso.split("-").map(Number);
  let total = (y2 * 12 + m2 - 1) - (y1 * 12 + m1 - 1);
  let dd = d2 - d1;
  if (total > 0 && dd < 0) {
    total--;
    const ty = y1 + Math.floor((m1 - 1 + total) / 12), tm = ((m1 - 1 + total) % 12) + 1;
    const td = Math.min(d1, daysInMonth(ty, tm));
    dd = epochDay(dateIso) - Math.round(Date.UTC(ty, tm - 1, td) / 86400000);
  } else if (total < 0 && dd > 0) {
    total++;
    dd -= daysInMonth(y2, m2);
  }
  const years = Math.trunc(total / 12), months = total % 12;
  return {
    days, months: days / DAYS_PER_MONTH, yearsDec: days / 365.25, y: years, m: months, d: dd,
    text: days < 0 ? "before birth" : years > 0 ? `${years} y ${months} m ${dd} d` : months > 0 ? `${months} m ${dd} d` : `${dd} d`,
    short: days < 0 ? "–" : years > 0 ? `${years} y ${months} m` : `${months} m ${dd} d`,
  };
}

export function mph(sex, father, mother) { return (father + mother + (sex === "M" ? 13 : -13)) / 2; }
export const MPH_RANGE = 8.5;

/** Percentile as text inside brackets, e.g. "25", "0.4", ">99.9". */
export function pctTxt(a) {
  if (!a) return "";
  const p = a.p;
  return p < 0.1 ? "<0.1" : p > 99.9 ? ">99.9" : p < 1 || p > 99 ? String(Math.round(p * 10) / 10) : String(Math.min(99, Math.max(1, Math.round(p))));
}
export function fmtNum(v, dp = 1) { const r = Math.round(v * 10 ** dp) / 10 ** dp; return String(r); }

/**
 * Genetic target channel from mid-parental height: the percentile of MPH (and of MPH ± 8.5 cm)
 * on the CDC 2000 stature-for-age curve at 20 years. The same z-scores are traced back through
 * childhood on whichever chart is displayed.
 */
export function mphTarget(sex, mphCm) {
  if (!mphCm) return null;
  const h = refs["cdc2000_child"]?.measures.height; if (!h) return null;
  const p = lms(h, sex, 240); if (!p) return null;
  const z = zOf(p, mphCm), zlo = zOf(p, mphCm - MPH_RANGE), zhi = zOf(p, mphCm + MPH_RANGE);
  return { mph: mphCm, z, zlo, zhi, pct: cdf(z) * 100 };
}

/** Compact percentile for chart labels, e.g. "P36", "P0.4", "<P0.1". */
export function pctShort(a) {
  if (!a) return "";
  const p = a.p;
  if (p < 0.1) return "<P0.1"; if (p > 99.9) return ">P99.9";
  return "P" + (p < 1 || p > 99 ? (Math.round(p * 10) / 10) : Math.min(99, Math.max(1, Math.round(p))));
}

/** Value with percentile in brackets, e.g. "120 cm (25%)", "23 kg (2%)", "95 cm (0.4%)". */
export function withPct(value, unit, a) {
  const v = `${value} ${unit}`;
  return a ? `${v} (${pctTxt(a)}%)` : v;
}

/** Date of birth estimated from an age (years, months, days) on a given date — calendar subtraction. */
export function dobFromAge(onIso, y, m, d) {
  const [yy, mm, dd] = onIso.split("-").map(Number);
  let total = yy * 12 + (mm - 1) - (y * 12 + m);
  const ty = Math.floor(total / 12), tm = total % 12 + 1;
  const day = Math.min(dd, new Date(Date.UTC(ty, tm, 0)).getUTCDate());
  const t = Date.UTC(ty, tm - 1, day) - d * 86400000;
  return new Date(t).toISOString().slice(0, 10);
}
/** "01/11/2018" or "≈ 01/11/2018 (estimated from age 7 y 10 m on 24/09/2026)". */
export function fmtDob(p, long = true) {
  if (!p.dobEstimated) return fmtDate(p.dob);
  const a = p.ageEntered;
  const ageTxt = a ? [a.y ? `${a.y} y` : "", a.m ? `${a.m} m` : "", a.d ? `${a.d} d` : ""].filter(Boolean).join(" ") || "0 d" : "";
  return long && a ? `≈ ${fmtDate(p.dob)} (estimated from age ${ageTxt} on ${fmtDate(a.on)})` : `≈ ${fmtDate(p.dob)} (estimated)`;
}
